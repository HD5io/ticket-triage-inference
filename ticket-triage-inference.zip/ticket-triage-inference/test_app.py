from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import app as service
from train import train


@pytest.fixture(scope="session")
def model_path(tmp_path_factory):
    path = tmp_path_factory.mktemp("model") / "model.joblib"
    assert train(Path("data/tickets.csv"), path)["cv_accuracy"] > 0.75
    return path


@pytest.fixture
def client(model_path, monkeypatch):
    monkeypatch.setenv("MODEL_PATH", str(model_path))
    with TestClient(service.app) as c:
        yield c


def test_ready_reports_model_version(client):
    assert client.get("/health").json() == {"status": "ok"}
    assert len(client.get("/ready").json()["version"]) == 12


def test_predict_routes_a_batch(client):
    tickets = ["I forgot my password and cannot log in", "How do I renew a library book"]
    body = client.post("/predict", json={"tickets": tickets}).json()
    assert [p["queue"] for p in body["predictions"]] == ["it_support", "library"]
    assert "triage_tickets_total 2" in client.get("/metrics").text


def test_unsure_ticket_goes_to_a_human(client, monkeypatch):
    monkeypatch.setenv("CONFIDENCE_THRESHOLD", "0.99")
    body = client.post("/predict", json={"tickets": ["hello there"]}).json()
    assert body["predictions"][0]["queue"] == "needs_human"


def test_bad_input_is_rejected(client):
    for tickets in ([], ["   "], ["x"] * 65):
        assert client.post("/predict", json={"tickets": tickets}).status_code == 422


def test_not_ready_without_a_model(monkeypatch, tmp_path):
    monkeypatch.setenv("MODEL_PATH", str(tmp_path / "missing.joblib"))
    with TestClient(service.app) as c:
        assert (c.get("/health").status_code, c.get("/ready").status_code) == (200, 503)
        assert c.post("/predict", json={"tickets": ["hi"]}).status_code == 503
