"""Inference server that routes support tickets to a queue. Run: uvicorn app:app"""

import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

import joblib
from fastapi import FastAPI, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("triage")
FALLBACK_QUEUE = "needs_human"
model: dict = {}
counters = {"requests": 0, "tickets": 0, "low_confidence": 0, "inference_seconds": 0.0}


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Load the model once at startup instead of on every request."""
    path = Path(os.getenv("MODEL_PATH", "model/model.joblib"))
    if path.exists():
        model.update(joblib.load(path))
        log.info("loaded model %s from %s", model["meta"]["version"], path)
    else:
        log.error("no model at %s: /ready returns 503 until train.py is run", path)
    yield
    model.clear()


app = FastAPI(title="Ticket triage inference", lifespan=lifespan)


class PredictRequest(BaseModel):
    tickets: list[str] = Field(min_length=1, max_length=64)


class Prediction(BaseModel):
    queue: str
    confidence: float
    scores: dict[str, float]


class PredictResponse(BaseModel):
    model_version: str
    predictions: list[Prediction]


@app.get("/health")
def health() -> dict:
    """Liveness: the process is up."""
    return {"status": "ok"}


@app.get("/ready")
def ready() -> dict:
    """Readiness: the model is loaded and can take traffic."""
    if not model:
        raise HTTPException(status_code=503, detail="model not loaded")
    return {"status": "ready", **model["meta"]}


@app.post("/predict")
def predict(request: PredictRequest) -> PredictResponse:
    ready()  # raises 503 if the model is not loaded
    if any(not t.strip() for t in request.tickets):
        raise HTTPException(status_code=422, detail="tickets must not be empty")
    started = time.perf_counter()
    threshold = float(os.getenv("CONFIDENCE_THRESHOLD", "0.5"))
    pipeline, predictions = model["pipeline"], []
    # One predict call for the whole batch is much cheaper than one call per ticket.
    for row in pipeline.predict_proba(request.tickets):
        scores = {str(c): round(float(p), 3) for c, p in zip(pipeline.classes_, row)}
        best = max(scores, key=scores.get)
        confident = scores[best] >= threshold
        # An unsure model hands the ticket to a person rather than guessing.
        queue = best if confident else FALLBACK_QUEUE
        counters["low_confidence"] += not confident
        predictions.append(Prediction(queue=queue, confidence=scores[best], scores=scores))
    elapsed = time.perf_counter() - started
    counters["requests"] += 1
    counters["tickets"] += len(predictions)
    counters["inference_seconds"] += elapsed
    log.info("predicted %d tickets in %.1f ms", len(predictions), elapsed * 1000)
    return PredictResponse(model_version=model["meta"]["version"], predictions=predictions)


@app.get("/metrics", response_class=PlainTextResponse)
def metrics() -> str:
    """Counters in Prometheus text format."""
    lines = [f"triage_{name}_total {value}" for name, value in counters.items()]
    return "\n".join(lines + [f"triage_model_loaded {int(bool(model))}"]) + "\n"
