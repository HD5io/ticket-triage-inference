"""Train the ticket triage model and save it as a versioned artifact."""

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline


def load(path: Path) -> tuple[list[str], list[str]]:
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    return [r["text"] for r in rows], [r["queue"] for r in rows]


def train(data: Path, out: Path) -> dict:
    texts, labels = load(data)
    pipeline = make_pipeline(
        # Character n-grams cope with typos and word endings better than whole words.
        TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), sublinear_tf=True),
        LogisticRegression(C=10, max_iter=1000),
    )
    # Cross-validate first, so the accuracy comes from tickets the model has not seen.
    folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
    accuracy = cross_val_score(pipeline, texts, labels, cv=folds).mean()
    pipeline.fit(texts, labels)
    # Version = hash of the training data, so a data change shows up in every response.
    meta = {
        "version": hashlib.sha256(data.read_bytes()).hexdigest()[:12],
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "cv_accuracy": round(float(accuracy), 3),
        "labels": sorted(set(labels)),
        "examples": len(texts),
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline": pipeline, "meta": meta}, out)
    return meta


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path("data/tickets.csv"))
    parser.add_argument("--out", type=Path, default=Path("model/model.joblib"))
    args = parser.parse_args()
    print(json.dumps(train(args.data, args.out), indent=2))
